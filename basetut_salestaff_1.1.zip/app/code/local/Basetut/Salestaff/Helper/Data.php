<?php

class Basetut_Salestaff_Helper_Data extends Mage_Core_Helper_Abstract {
}