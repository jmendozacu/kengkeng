<?php  

class ABSoft_Import_Block_Adminhtml_Importbackend extends Mage_Adminhtml_Block_Template {

}